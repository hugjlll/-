import sys
from IDidentify.ID_identifyAPP import ID_identifyApp
if __name__ == '__main__':
    app = ID_identifyApp()
    sys.exit(app.exec())
