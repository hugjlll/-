pip install PyQt5
pip install pyqt5-tools
pip install opencv-python
pip install Pillow
